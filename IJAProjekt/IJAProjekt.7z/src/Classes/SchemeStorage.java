/**
 *
 * @author Jan Rajnoha, xrajno09
 */

package Classes;

import java.util.Hashtable;

public class SchemeStorage {

    public ObjectSize TableSize;
    public Hashtable<String, Block> BlockDictionary;

    public SchemeStorage()
    {}

}
